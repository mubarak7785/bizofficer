import "./Filter.css"

export const Filter=()=>{
    return(<div>
        <div className="main-con">
            <select name="" id=""></select>
            <select name="" id=""></select>
            <select name="" id=""></select>
            <select name="" id=""></select>
        </div>
    </div>)
}